import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class LevelWonMenu extends JPanel {

    private JLabel scoreLabel;

    public LevelWonMenu(Runnable retry, Runnable next, Runnable exit) {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(UIStyle.PANEL_BG);
        setOpaque(true);
        setBorder(BorderFactory.createEmptyBorder(50, 100, 50, 100));

        JLabel title = new JLabel("Level Won!");
        title.setFont(UIStyle.TITLE_FONT);
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(Box.createVerticalGlue());
        add(title);
        add(Box.createRigidArea(new Dimension(0, 40)));

        scoreLabel = new JLabel("Score: 0 (Cleared: 0, Killed: 0)");
        scoreLabel.setFont(UIStyle.BUTTON_FONT);
        scoreLabel.setForeground(Color.CYAN);
        scoreLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(scoreLabel);
        add(Box.createRigidArea(new Dimension(0, 20)));

        add(MenuUIFactory.createMenuButton("Retry", retry));
        add(Box.createRigidArea(new Dimension(0, 15)));
        add(MenuUIFactory.createMenuButton("Next Level", next));
        add(Box.createRigidArea(new Dimension(0, 15)));
        add(MenuUIFactory.createMenuButton("Quit to Menu", exit));
        add(Box.createVerticalGlue());
    }

    public void updateScore(Model gameworld) {
        if (gameworld != null) {
            int cleared = gameworld.getConvoyGoal();
            int killed = gameworld.getKilledConvoys();
            int score = cleared * 10 + killed * 5;
            scoreLabel.setText("Score: " + score + " (Cleared: " + cleared + ", Killed: " + killed + ")");
        }
    }
}