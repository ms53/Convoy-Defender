import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.util.function.Consumer;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class LevelSelectionMenu extends JPanel {

    public LevelSelectionMenu(LevelManager manager,
                              Consumer<Integer> levelSelect,
                              Runnable menuAction) {

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(UIStyle.PANEL_BG);
        setOpaque(true);
        setBorder(BorderFactory.createEmptyBorder(50, 100, 50, 100));

        JLabel title = new JLabel("LEVEL SELECT");
        title.setFont(UIStyle.TITLE_FONT);
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        add(Box.createVerticalGlue());
        add(title);
        add(Box.createRigidArea(new Dimension(0, 30)));

        for (int i = 0; i < 6; i++) {
            int levelIndex = i;

            add(MenuUIFactory.createMenuButton(
                    "Level " + (i + 1),
                    () -> levelSelect.accept(levelIndex)
            ));

            add(Box.createRigidArea(new Dimension(0, 15)));
        }

        add(MenuUIFactory.createMenuButton("Back", menuAction));
        add(Box.createVerticalGlue());
    }
}
