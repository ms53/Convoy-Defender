import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;

import util.GameObject;
import util.Point3f;
import util.Vector3f; 

public class Model {
	
	 private  GameObject Player;
	 private  GameObject Player2;
	 private Controller controller;
	 private  CopyOnWriteArrayList<GameObject> EnemiesList  = new CopyOnWriteArrayList<GameObject>();
	 private CopyOnWriteArrayList<GameObject> FastEnemies = new CopyOnWriteArrayList<>();
	 private CopyOnWriteArrayList<GameObject> ConvoyList = new CopyOnWriteArrayList<GameObject>();
	 private  CopyOnWriteArrayList<GameObject> BulletList  = new CopyOnWriteArrayList<GameObject>();
	 private CopyOnWriteArrayList<GameObject> HealthList = new CopyOnWriteArrayList<GameObject>();
	 private CopyOnWriteArrayList<GameObject> AmmoList = new CopyOnWriteArrayList<GameObject>();
	 private CopyOnWriteArrayList<GameObject> ShieldList = new CopyOnWriteArrayList<>();

	 private Level currentLevel;
	 private int Score=0;
	 private int lives = 3;
	 //private int livesP2 = 3;
	 private int maxLives = 10;
	 private int ammo = 20;
	 private int maxAmmo = 50;
	 private CopyOnWriteArrayList<Shield> player1Shields = new CopyOnWriteArrayList<>();
	 private CopyOnWriteArrayList<Shield> player2Shields = new CopyOnWriteArrayList<>();
	 private int shields = 0;
	 private int maxShields = 5;
	 private int levelKills = 0;
	 private int killedConvoys = 0;
	 private int convoyGoal = 0;
	 private float worldWidth = 1500;
	 private float worldHeight = 775;
	 private float spawnTimer = 0f;
	 private float spawnInterval;
	 private float convoyDropTimer = 0f;
	 private float convoyDropInterval = 15f;

	public Model(float worldWidth, float worldHeight, Controller controller, Level level, boolean multiplayer) {
		 //setup game world
		this.worldWidth = worldWidth;
		this.worldHeight = worldHeight;
		this.controller = controller;
		this.currentLevel = level;
	    spawnInterval = 2.0f - (currentLevel.getLevelNumber() * 0.3f);
	    spawnInterval = Math.max(0.5f, spawnInterval);
		//Player 
		Player= new GameObject("res/MyShip.png",50,50,new Point3f(500,500,0));
		if (multiplayer)
			Player2 = new GameObject("res/MyShip2.png", 50, 50, new Point3f(800, 500, 0));
		else
			Player2 = null;
		
	}
	
	// This is the heart of the game , where the model takes in all the inputs ,decides the outcomes and then changes the model accordingly. 
	public void gamelogic(double deltaTime) 
	{
		// Player Logic first 
		playerLogic(deltaTime); 
		// Enemy Logic next
		enemyLogic(deltaTime);
		// Convoy move next
		convoyLogic(deltaTime);
		// Bullets move next 
		bulletLogic(deltaTime);
		// Drops move next
		dropLogic(deltaTime);
		// interactions between objects 
		gameLogic();
		
	   
	}

	private void gameLogic() { 
		
		
		// this is a way to increment across the array list data structure 

		
		//see if they hit anything 
		// using enhanced for-loop style as it makes it alot easier both code wise and reading wise too 
		for (GameObject temp : EnemiesList) 
		{
			for (Shield shield : player1Shields) {
		        if (collision(temp, shield.getShieldObject())) {
		            shield.absorbHit();
		            EnemiesList.remove(temp);
		            if (shield.isDestroyed()) player1Shields.remove(shield);
		            continue;
		        }
		    }

			for (Shield shield : player2Shields) {
		        if (collision(temp, shield.getShieldObject())) {
		            shield.absorbHit();
		            EnemiesList.remove(temp);
		            if (shield.isDestroyed()) player2Shields.remove(shield);
		            continue;
		        }
		    }

		for (GameObject Bullet : BulletList) 
		{
			if ( collision(temp,Bullet))
			{
				EnemiesList.remove(temp);
				BulletList.remove(Bullet);
				Score++;
				levelKills++;
				
				
			}  
		}
		for (GameObject convoy : ConvoyList)
		{
			if ( collision(temp,convoy))
			{
				EnemiesList.remove(temp);
				ConvoyList.remove(convoy);
				killedConvoys ++;
			}
		}
		if (collision(temp,Player) || (Player2 != null && collision(temp,Player2)))
		{
			EnemiesList.remove(temp);
			loseLife();
		}
 
		
		}
		for (GameObject temp : FastEnemies) 
		{
			for (Shield shield : player1Shields) {
		        if (collision(temp, shield.getShieldObject())) {
		            shield.absorbHit();
		            EnemiesList.remove(temp);
		            if (shield.isDestroyed()) player1Shields.remove(shield);
		            continue;
		        }
		    }

			for (Shield shield : player2Shields) {
		        if (collision(temp, shield.getShieldObject())) {
		            shield.absorbHit();
		            EnemiesList.remove(temp);
		            if (shield.isDestroyed()) player2Shields.remove(shield);
		            continue;
		        }
		    }
		for (GameObject Bullet : BulletList) 
		{
			if ( collision(temp,Bullet))
			{
				FastEnemies.remove(temp);
				BulletList.remove(Bullet);
				Score++;
				levelKills++;
				
				
			}  
		}
		for (GameObject convoy : ConvoyList)
		{
			if ( collision(temp,convoy))
			{
				FastEnemies.remove(temp);
				ConvoyList.remove(convoy);
				killedConvoys ++;
			}
		}
		if ( collision(temp,Player) || (Player2 != null && collision(temp,Player2)))
		{
			FastEnemies.remove(temp);
			loseLife();
		}
 
	
		}
		
	}

	private void enemyLogic(double deltaTime) {
	    float enemySpeed = currentLevel.getEnemySpeed();
	    float fastSpeed = (float) (enemySpeed *1.8);
	    for (GameObject enemy : EnemiesList) {
	        // Move downwards
	        enemy.getCentre().ApplyVector(new Vector3f(0, +enemySpeed * (float) deltaTime, 0));

	        // Remove if offscreen (bottom)
	        if (enemy.getCentre().getY() > worldHeight) {
	            EnemiesList.remove(enemy);
	        }
	    }
	    for (GameObject enemy : FastEnemies) {
	        // Move downwards
	        enemy.getCentre().ApplyVector(new Vector3f(0, +fastSpeed * (float) deltaTime, 0));

	        // Remove if offscreen (bottom)
	        if (enemy.getCentre().getY() > worldHeight) {
	            FastEnemies.remove(enemy);
	        }
	    }

	    spawnTimer += deltaTime;
	    
	    if(spawnTimer >= spawnInterval &&
	    	EnemiesList.size() < currentLevel.getNumEnemies()) {
	    	if(Math.random() > 0.7 && currentLevel.getLevelNumber() > 3) {
	    	float randomX = (float) (Math.random() * (worldWidth - 50));
	        FastEnemies.add(new GameObject(
	            "res/AlienEye2.png",
	            50,
	            50,
	            new Point3f(randomX, 0, 0)
	        ));

	        spawnTimer = 0f;
	    	}else {
	    		float randomX = (float) (Math.random() * (worldWidth - 50));
		        EnemiesList.add(new GameObject(
		            "res/AlienEye.png",
		            50,
		            50,
		            new Point3f(randomX, 0, 0)
		        ));

		        spawnTimer = 0f;
	    	}
	    }
	}
	
	private void convoyLogic(double deltaTime) {
		float convoySpeed = 50f;
		for(GameObject convoy : ConvoyList) {
			//Move rightwards
			convoy.getCentre().ApplyVector(new Vector3f(convoySpeed * (float) deltaTime, 0, 0));
			convoyDropTimer += deltaTime;
	        if(convoyDropTimer >= convoyDropInterval) {
	            double random = Math.random();
	            if(random < 0.45)
	                spawnHealthDrop(convoy.getCentre().getX(), convoy.getCentre().getY());
	            else if(random < 0.9)
	                spawnAmmoDrop(convoy.getCentre().getX(), convoy.getCentre().getY());
	            else
	            	spawnShieldDrop(convoy.getCentre().getX(), convoy.getCentre().getY());
	            convoyDropTimer = 0f;
	        }
			if(convoy.getCentre().getX() > worldWidth) {
				ConvoyList.remove(convoy);
				convoyGoal ++;
			}
		}
		if(ConvoyList.size() < currentLevel.getConvoySize()) {
			if (ConvoyList.isEmpty()) {
				spawnConvoyShip();
			} else {
				GameObject lastShip = ConvoyList.get(ConvoyList.size() - 1);
				
				if (lastShip.getCentre().getX() > 50) {
					spawnConvoyShip();
				}
			}
		}
	}

	private void bulletLogic(double deltaTime) {
	    float bulletSpeed = 500f;

	    for (GameObject bullet : BulletList) {
	        bullet.getCentre().ApplyVector(new Vector3f(0, -bulletSpeed * (float) deltaTime, 0));
	        System.out.println(BulletList.size());

	        // Remove if offscreen (top)
	        if (bullet.getCentre().getY() < 0) {
	            BulletList.remove(bullet);
	        }
	    }
	}
	
	private void dropLogic(double deltaTime) {
		float dropSpeed = 40f;
		
		for(GameObject drop : HealthList) {
			drop.getCentre().ApplyVector(new Vector3f(0, -dropSpeed * (float) deltaTime, 0));
			if (drop.getCentre().getY() > worldHeight) HealthList.remove(drop);
		}
		
		for(GameObject drop : AmmoList) {
			drop.getCentre().ApplyVector(new Vector3f(0, -dropSpeed * (float) deltaTime, 0));
			if (drop.getCentre().getY() > worldHeight) AmmoList.remove(drop);
		}
		
		for(GameObject drop : ShieldList) {
		    drop.getCentre().ApplyVector(new Vector3f(0, -dropSpeed * (float)deltaTime, 0));
		}
		
	}

	private void playerLogic(double deltaTime) {

	    float playerSpeed = 400f; // pixels per second
	    float moveAmount = playerSpeed * (float) deltaTime;

	    float dx = 0f;
	    float dy = 0f;
	    
	    float dx2 = 0f;
	    float dy2 = 0f;

	    if (controller.isKeyAPressed()) dx -= moveAmount;
	    if (controller.isKeyDPressed()) dx += moveAmount;
	    if (controller.isKeyWPressed()) dy -= moveAmount;
	    if (controller.isKeySPressed()) dy += moveAmount;
	   if(Player2 != null) {
	    if (controller.isKeyLeftPressed()) dx2 -= moveAmount;
	    if (controller.isKeyRightPressed()) dx2 += moveAmount;
	    if (controller.isKeyUpPressed()) dy2 -= moveAmount;
	    if (controller.isKeyDownPressed()) dy2 += moveAmount;
	    Player2.getCentre().ApplyVector(new Vector3f(dx2, dy2, 0));
	    float halfWidth = Player2.getWidth() / 2f;
	    float halfHeight = Player2.getHeight() / 2f;

	    float clampedX = Math.max(halfWidth, Math.min(worldWidth - halfWidth, Player2.getCentre().getX()));
	    float clampedY = Math.max(halfHeight, Math.min(worldHeight - halfHeight, Player2.getCentre().getY()));

	    Player2.getCentre().setX(clampedX);
	    Player2.getCentre().setY(clampedY);
	   }
	    Player.getCentre().ApplyVector(new Vector3f(dx, dy, 0));

	    // Enforce boundaries based on world size
	    float halfWidth = Player.getWidth() / 2f;
	    float halfHeight = Player.getHeight() / 2f;

	    float clampedX = Math.max(halfWidth, Math.min(worldWidth - halfWidth, Player.getCentre().getX()));
	    float clampedY = Math.max(halfHeight, Math.min(worldHeight - halfHeight, Player.getCentre().getY()));

	    Player.getCentre().setX(clampedX);
	    Player.getCentre().setY(clampedY);

	    // Shoot bullets
	    if (controller.isKeySpacePressed()) {
	    	if(ammo > 0) {
	        CreateBullet();
	        ammo--;
	    	}
	        controller.setKeySpacePressed(false);
	    }
	    
	    if (Player2 != null && controller.isKeyEnterPressed()) {
	    	if(ammo > 0) {
	        CreateBulletP2();
	        ammo--;
	    	}
	        controller.setKeyEnterPressed(false);
	    }
	    
	    // Deploy shields
	    if (controller.isKeyDeployP1Pressed() && shields > 0) {
	        GameObject shieldObj = new GameObject("res/Shield.png", 64, 32,
	            new Point3f(Player.getCentre().getX() - 32, Player.getCentre().getY() - 16, 0));
	        Shield shield = new Shield(shieldObj);
	        player1Shields.add(shield);
	        shields--;
	        controller.setKeyDeployP1Pressed(false);
	    }

	    if (Player2 != null && controller.isKeyDeployP2Pressed() && shields > 0) {
	        GameObject shieldObj = new GameObject("res/Shield.png", 64, 32,
	            new Point3f(Player2.getCentre().getX() - 32, Player2.getCentre().getY() - 16, 0));
	        Shield shield = new Shield(shieldObj);
	        player2Shields.add(shield);
	        shields--;
	        controller.setKeyDeployP2Pressed(false);
	    }
	    
	    // Collect hearts
	    for (GameObject drop : HealthList) {
	        if (collision(Player,drop) || (Player2 != null &&collision(Player2,drop))) {
	        	
	        	if(lives < maxLives) lives++; // increment player's health
	            HealthList.remove(drop);
	        }
	    }
	    // Collect ammo
	    for (GameObject drop : AmmoList) {
	        if (collision(Player,drop) || (Player2 != null && collision(Player2,drop))) {

	            if (ammo < maxAmmo) ammo += 5; // give ammo
	            AmmoList.remove(drop);
	        }
	    }
	    
	    // Collect shields
	    for (GameObject drop : ShieldList) {
	        if (collision(Player,drop) || (Player2 != null && collision(Player2,drop))) {
	            if(shields < maxShields) shields++;
	            ShieldList.remove(drop);
	        }
	    }
	    
	}

	private void CreateBullet() {
		BulletList.add(new GameObject("res/NewBullet.png",32,64,new Point3f(Player.getCentre().getX()+10,Player.getCentre().getY()-40,0.0f)));
		
	}
	
	private void CreateBulletP2() {
	    BulletList.add(new GameObject("res/NewBullet.png",
	            32, 64,
	            new Point3f(Player2.getCentre().getX()+10,
	                        Player2.getCentre().getY()-40, 0)));
	}
	
	private void spawnConvoyShip() {
	    ConvoyList.add(new GameObject(
	        "res/convoyShip.png",
	        50,
	        50,
	        new Point3f(0, worldHeight-50, 0)
	    ));
	}
	
	private void loseLife() {
		lives--;
	}
	
	private void spawnHealthDrop(float x, float y) {
	    HealthList.add(new GameObject("res/Heart.png", 12, 12, new Point3f(x, y, 0)));
	}
	
	public CopyOnWriteArrayList<GameObject> getHealthDrops() {
		return HealthList;
	}
	
	public CopyOnWriteArrayList<GameObject> getAmmoDrops() {
		return AmmoList;
	}
	
	public CopyOnWriteArrayList<GameObject> getShieldDrops() {
		return ShieldList;
	}

	private void spawnAmmoDrop(float x, float y) {
	    AmmoList.add(new GameObject("res/Ammo.png", 16, 16, new Point3f(x, y, 0)));
	}
	
	private void spawnShieldDrop(float x, float y) {
	    ShieldList.add(new GameObject("res/shieldDrop.png", 12, 12, new Point3f(x, y, 0)));
	}
	
	public boolean isLevelComplete() {
		return convoyGoal == currentLevel.getConvoysToClear();
	}
	
	public boolean isGameOver() {
		return lives <= 0 || killedConvoys > currentLevel.getConvoySize()/2;
	}

	public GameObject getPlayer() {
		return Player;
	}
	
	public GameObject getPlayer2() {
		return Player2;
	}

	public CopyOnWriteArrayList<GameObject> getEnemies() {
		return EnemiesList;
	}
	
	public CopyOnWriteArrayList<GameObject> getFastEnemies() {
		return FastEnemies;
	}
	
	public CopyOnWriteArrayList<GameObject> getConvoys() {
		return ConvoyList;
	}
	
	public CopyOnWriteArrayList<GameObject> getBullets() {
		return BulletList;
	}
	
	public int getShields() {
		return shields;
	}

	public int getScore() { 
		return Score;
	}
	
	public int getKilledConvoys() {
		return killedConvoys;
	}
	
	public int getConvoyGoal() {
		return convoyGoal;
	}
	
	public int getLives() {
		return lives;
	}
	
	public int getAmmo() {
		return ammo;
	}
	
	public Level getCurrentLevel() {
		return currentLevel;
	}
	
	public float[] getWorldSize() {
		float coords[] = {worldWidth, worldHeight};
		return coords;
	}

	public CopyOnWriteArrayList<Shield> getPlayer1Shields() {
		// TODO Auto-generated method stub
		return player1Shields;
	}
	
	public CopyOnWriteArrayList<Shield> getPlayer2Shields() {
		// TODO Auto-generated method stub
		return player2Shields;
	}

	private boolean collision(GameObject a, GameObject b) {
	    float ax = a.getCentre().getX();
	    float ay = a.getCentre().getY();
	    float aw = a.getWidth();
	    float ah = a.getHeight();

	    float bx = b.getCentre().getX();
	    float by = b.getCentre().getY();
	    float bw = b.getWidth();
	    float bh = b.getHeight();

	    return Math.abs(ax - bx) < (aw/2 + bw/2) &&
	           Math.abs(ay - by) < (ah/2 + bh/2);
	}
 

}
