import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PauseMenu extends JPanel {
	public PauseMenu(Runnable onResume, Runnable onQuit) {
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		setBackground(UIStyle.PANEL_BG);
        setOpaque(true);
        setBorder(BorderFactory.createEmptyBorder(50, 100, 50, 100));

        JLabel title = new JLabel("Paused");
        title.setFont(UIStyle.TITLE_FONT);
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        add(Box.createVerticalGlue());
        add(title);
        add(Box.createRigidArea(new Dimension(0, 40)));
        add(MenuUIFactory.createMenuButton("Resume", onResume));
        add(Box.createRigidArea(new Dimension(0, 15)));
        add(MenuUIFactory.createMenuButton("Quit to Menu", onQuit));
        add(Box.createVerticalGlue());

	}
}
