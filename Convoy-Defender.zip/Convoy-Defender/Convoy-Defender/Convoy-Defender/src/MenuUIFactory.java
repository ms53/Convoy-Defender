import javax.swing.*;
import java.awt.*;
public class MenuUIFactory {
	public static JButton createMenuButton(String text, Runnable action) {
        JButton button = new JButton(text);
        button.setFont(UIStyle.BUTTON_FONT);
        button.setForeground(UIStyle.BUTTON_TEXT);
        button.setBackground(UIStyle.BUTTON_BG);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 30, 10, 30));
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.addActionListener(e -> action.run());

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(UIStyle.BUTTON_HOVER);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(UIStyle.BUTTON_BG);
            }
        });

        return button;
    }
}
