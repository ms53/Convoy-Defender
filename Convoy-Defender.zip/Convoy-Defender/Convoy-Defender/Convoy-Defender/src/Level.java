
public class Level {
    private int levelNumber;
    private int numEnemies;
    private float enemySpeed;
    private int convoySize;
    private int convoysToClear;

    public Level(int levelNumber, int numEnemies, float enemySpeed, int convoySize, int convoysToClear) {
        this.levelNumber = levelNumber;
        this.numEnemies = numEnemies;
        this.enemySpeed = enemySpeed;
        this.convoySize = convoySize;
        this.convoysToClear = convoysToClear;
    }

    public int getNumEnemies() { return numEnemies; }
    public float getEnemySpeed() { return enemySpeed; }
    public int getLevelNumber() { return levelNumber; }
    public int getConvoySize() {return convoySize;}
    public int getConvoysToClear() {return convoysToClear;}
}