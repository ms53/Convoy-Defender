import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.LayoutManager;
import java.awt.Rectangle;
import java.awt.TexturePaint;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.Timer;

import util.GameObject;

public class Viewer extends JPanel {
	private long CurrentAnimationTime= 0;
	
	private Model gameworld; 
	private Image backgroundImage;
	private Image heartImage;
	private Image shieldImage;
	private Map<String, Image> textureCache = new HashMap<>();
	
	public Viewer(Model gameworld) {
		if (gameworld == null) throw new IllegalArgumentException("Model cannot be null");
		this.gameworld=gameworld;
		try {
			backgroundImage = ImageIO.read(new File("res/flesh_wall.png")); //source: https://www.newgrounds.com/art/view/steveadmin/living-wall-flesh-wallpaper-frames "Living Wall Flesh Wallpaper Frames" by SteveAdmin
		} catch (IOException e) {
			e.printStackTrace();
		}
		// TODO Auto-generated constructor stub
		try {
			heartImage = ImageIO.read(new File("res/heartDisplay.png")); //custom made image
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		try {
		    shieldImage = ImageIO.read(new File("res/shieldIcon.png")); // custom made image
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
	}

	public Viewer(LayoutManager layout, Model gameworld) {
		super(layout);
		if (gameworld == null) throw new IllegalArgumentException("Model cannot be null");
        this.gameworld = gameworld;
		// TODO Auto-generated constructor stub
	}

	public void updateView() {
		
		this.repaint();
		// TODO Auto-generated method stub
		
	}
	
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		if (gameworld == null) return;
		CurrentAnimationTime++; // runs animation time step 
		int canvasWidth = getWidth();
		int canvasHeight = getHeight();
		float coords[] = gameworld.getWorldSize();
		double scaleX = canvasWidth / coords[0];
		double scaleY = canvasHeight / coords[1];
		double scale = Math.min(scaleX, scaleY);
		//Draw background 
		drawBackground(g, canvasWidth, canvasHeight, scale);
		//Draw player Game Object 
		int x = (int) gameworld.getPlayer().getCentre().getX();
		int y = (int) gameworld.getPlayer().getCentre().getY();
		int width = (int) gameworld.getPlayer().getWidth();
		int height = (int) gameworld.getPlayer().getHeight();
		String texture = gameworld.getPlayer().getTexture();
 
		if(gameworld.getPlayer2() != null) {
		    int x2 = (int) gameworld.getPlayer2().getCentre().getX();
		    int y2 = (int) gameworld.getPlayer2().getCentre().getY();
		    int width2 = (int) gameworld.getPlayer2().getWidth();
		    int height2 = (int) gameworld.getPlayer2().getHeight();
		    String texture2 = gameworld.getPlayer2().getTexture();

		    drawPlayer(x2, y2, width2, height2, texture2, g, scale);
		}
		
		
		
		//Draw player
		drawPlayer(x, y, width, height, texture,g, scale);
		  
		//Draw Bullets 
		// change back 
		gameworld.getBullets().forEach((temp) -> 
		{ 
			drawBullet((int) temp.getCentre().getX(), (int) temp.getCentre().getY(), (int) temp.getWidth(), (int) temp.getHeight(), temp.getTexture(),g, scale);	 
		}); 
		
		//Draw Enemies   
		gameworld.getEnemies().forEach((temp) -> 
		{
			drawEnemies((int) temp.getCentre().getX(), (int) temp.getCentre().getY(), (int) temp.getWidth(), (int) temp.getHeight(), temp.getTexture(),g, scale);	 
		 
	    });
		
		gameworld.getFastEnemies().forEach((temp) -> 
		{
			drawEnemies((int) temp.getCentre().getX(), (int) temp.getCentre().getY(), (int) temp.getWidth(), (int) temp.getHeight(), temp.getTexture(),g, scale);	 
		 
	    });
		
		//Draw Convoys
		// Draw Convoy Ships
		gameworld.getConvoys().forEach((convoy) -> {
		    drawConvoy(
		        (int) convoy.getCentre().getX(),
		        (int) convoy.getCentre().getY(),
		        (int) convoy.getWidth(),
		        (int) convoy.getHeight(),
		        convoy.getTexture(),
		        g,
		        scale
		    );
		});
		
		//Draw Hearts
		gameworld.getHealthDrops().forEach(drop -> {
		    drawDrop((int) drop.getCentre().getX(), (int) drop.getCentre().getY(),
		                (int) drop.getWidth(), (int) drop.getHeight(),
		                drop.getTexture(), g, scale);
		});

		//Draw Ammo
		gameworld.getAmmoDrops().forEach(drop -> {
		    drawDrop((int) drop.getCentre().getX(), (int) drop.getCentre().getY(),
		                (int) drop.getWidth(), (int) drop.getHeight(),
		                drop.getTexture(), g, scale);
		});
		
		//Draw Shields
		gameworld.getShieldDrops().forEach(drop -> {
		    drawDrop(
		        (int) drop.getCentre().getX(),
		        (int) drop.getCentre().getY(),
		        (int) drop.getWidth(),
		        (int) drop.getHeight(),
		        drop.getTexture(),
		        g,
		        scale
		    );
		});

		// Player 1 shields
		for (Shield s : gameworld.getPlayer1Shields()) {
		    drawDrop(
		        (int)s.getShieldObject().getCentre().getX(),
		        (int)s.getShieldObject().getCentre().getY(),
		        64, 32,
		        s.getShieldObject().getTexture(),
		        g, scale
		    );
		}

		// Player 2 shields
		for (Shield s : gameworld.getPlayer2Shields()) {
		    drawDrop(
		        (int)s.getShieldObject().getCentre().getX(),
		        (int)s.getShieldObject().getCentre().getY(),
		        64, 32,
		        s.getShieldObject().getTexture(),
		        g, scale
		    );
		}
		
		//Draw Ammo
		g.setColor(Color.GREEN);
		g.drawString("Ammo: " + gameworld.getAmmo(), 20, 20);

		//Draw Shields
		g.setColor(Color.YELLOW);
		g.drawString("Shields: " + gameworld.getShields(), 20, 35);

		//Draw Level
		g.setColor(Color.WHITE);
		g.drawString("Level: " + gameworld.getCurrentLevel().getLevelNumber(), 100, 20);

		//Draw Convoy left
		g.setColor(Color.MAGENTA);
		g.drawString("Dead Convoys: "+ gameworld.getKilledConvoys() + "/" + gameworld.getCurrentLevel().getConvoySize()/2, 20, 50);

		//Draw Convoy Progress
		g.setColor(Color.CYAN);
		g.drawString("Convoys cleared: "+ gameworld.getConvoyGoal() + "/" + gameworld.getCurrentLevel().getConvoysToClear(), 20, 65);

		
		//Draw Lives
		drawLives(g);
		
		//Draw Shields
		drawShields(g);
		
	}
	
	private void drawEnemies(double x, double y, double width, double height, String texture,
            Graphics g, double scale) {
		File TextureToLoad = new File(texture);  //should work okay on OSX and Linux but check if you have issues depending your eclipse install or if your running this without an IDE 
		Image myImage = getTexture(texture);
		//The sprite is 32x32 pixel wide and 4 of them are placed together so we need to grab a different one each time 
		//remember your training :-) computer science everything starts at 0 so 32 pixels gets us to 31  
		int scaledX = (int)(x * scale);
		int scaledY = (int)(y * scale);
		int scaledWidth = (int)(width * scale);
		int scaledHeight = (int)(height * scale);
		int currentPositionInAnimation= ((int) ((CurrentAnimationTime%40 )/10)*32); //slows down animation so every 10 frames we get another frame so every 100ms 
		g.drawImage(myImage, scaledX,scaledY, scaledX+scaledWidth, scaledY+scaledHeight, currentPositionInAnimation  , 0, currentPositionInAnimation+31, 32, null); 
		
	}
	
	private void drawConvoy(double x, double y, double width, double height,
            String texture, Graphics g, double scale) {

		File textureFile = new File(texture);

		Image image = getTexture(texture);
		
		int scaledX = (int)(x * scale);
		int scaledY = (int)(y * scale);
		int scaledWidth = (int)(width * scale);
		int scaledHeight = (int)(height * scale);
		
		g.drawImage(image,
		    scaledX,
		    scaledY,
		    scaledWidth,
		    scaledHeight,
		    null);
	}

	private void drawBackground(Graphics g, int canvasWidth, int canvasHeight, double scale)
	{
		if(backgroundImage != null) {
			 g.drawImage(backgroundImage,0, 0,
			            canvasWidth,
			            canvasHeight,
			            0, 0, backgroundImage.getWidth(null), backgroundImage.getHeight(null),
			            null); 
		}
			
		
	}
	
	private void drawBullet(double x, double y, double width, double height, String texture,
            Graphics g, double scale)
	{
		File TextureToLoad = new File(texture);  //should work okay on OSX and Linux but check if you have issues depending your eclipse install or if your running this without an IDE 
		Image myImage = getTexture(texture); 
		int scaledX = (int)(x * scale);
		int scaledY = (int)(y * scale);
		int scaledWidth = (int)(width * scale);
		int scaledHeight = (int)(height * scale);
		//64 by 128 
		 g.drawImage(myImage, scaledX,scaledY, scaledX+scaledWidth, scaledY+scaledHeight, 0 , 0, 63, 127, null);
	}
	
	private void drawDrop(double x, double y, double width, double height, String texture,
            Graphics g, double scale) {
		
		File textureFile = new File(texture);
		
		Image myImage = getTexture(texture);
		
		int scaledX = (int)(x * scale);
		int scaledY = (int)(y * scale);
		int scaledWidth = (int)(width * scale);
		int scaledHeight = (int)(height * scale);
		
		int frameWidth = (int) width;
		int frameHeight = (int) height;
		
		int frameCount = myImage.getWidth(null) / frameWidth;
		
		int currentFrame = (int)((CurrentAnimationTime % (frameCount * 10)) / 10);
		int sx1 = currentFrame * frameWidth;
		int sx2 = sx1 + frameWidth;
		
		g.drawImage(myImage,
		      scaledX, scaledY,
		      scaledX + scaledWidth, scaledY + scaledHeight,
		      sx1, 0,
		      sx2, frameHeight,
		      null);
		}
	

	private void drawPlayer(double x, double y, double width, double height, String texture,
            Graphics g, double scale) { 
		File TextureToLoad = new File(texture);  //should work okay on OSX and Linux but check if you have issues depending your eclipse install or if your running this without an IDE 
		Image myImage = getTexture(texture);
		//The sprite is 32x32 pixel wide and 4 of them are placed together so we need to grab a different one each time 
		//remember your training :-) computer science everything starts at 0 so 32 pixels gets us to 31  
		int scaledX = (int)(x * scale);
		int scaledY = (int)(y * scale);
		int scaledWidth = (int)(width * scale);
		int scaledHeight = (int)(height * scale);
		int currentPositionInAnimation= ((int) ((CurrentAnimationTime%40)/10))*32; //slows down animation so every 10 frames we get another frame so every 100ms 
		g.drawImage(myImage, scaledX,scaledY, scaledX+scaledWidth, scaledY+scaledHeight, currentPositionInAnimation  , 0, currentPositionInAnimation+31, 32, null); 
		 
		//g.drawImage(img, dx1, dy1, dx2, dy2, sx1, sy1, sx2, sy2, observer));
		//Lighnting Png from https://opengameart.org/content/animated-spaceships  its 32x32 thats why I know to increament by 32 each time 
		// Bullets from https://opengameart.org/forumtopic/tatermands-art 
		// background image from https://www.needpix.com/photo/download/677346/space-stars-nebula-background-galaxy-universe-free-pictures-free-photos-free-images
		
	}
	
	private void drawLives(Graphics g) {
		if(heartImage == null) return;
		
		int lives = gameworld.getLives();
		int heartSize = 16;
		int spacing = 5;
		int startX = 140;
		int startY = 10;
		
		for(int i = 0; i < lives; i++) {
			int x = startX + i * (heartSize + spacing);
			g.drawImage(heartImage, x, startY, heartSize, heartSize, null);
		}
	}
	
	private void drawShields(Graphics g) {
	    if(shieldImage == null) return;

	    int shields = gameworld.getShields();
	    int shieldSize = 16;
	    int spacing = 5;
	    int startX = 140;
	    int startY = 35;

	    for(int i = 0; i < shields; i++) {
	        int x = startX + i * (shieldSize + spacing);
	        g.drawImage(shieldImage, x, startY, shieldSize, shieldSize, null);
	    }
	}

	public void setModel(Model gameworld2) {
		this.gameworld = gameworld2;
		// TODO Auto-generated method stub
		
	}
		 
	private Image getTexture(String path) {
	    if (!textureCache.containsKey(path)) {
	        try {
	            textureCache.put(path, ImageIO.read(new File(path)));
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	    return textureCache.get(path);
	}

}