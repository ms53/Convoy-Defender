import java.util.ArrayList;
import java.util.List;

public class LevelManager {
	private List<Level> levels = new ArrayList<>();
	private int currentLevelIndex = 0;
	
	public LevelManager() {
		
		levels.add(new Level(1, 6, 50f, 10, 18));
		levels.add(new Level(2, 10, 70f, 15, 30));
		levels.add(new Level(3, 13, 90f, 30, 60));
		levels.add(new Level(4, 13, 100f, 40, 70));
		levels.add(new Level(5, 13, 90f, 55, 80));
		levels.add(new Level(6, 13, 90f, 75, 100));

	}
	
	public Level getCurrentLevel() {
		return levels.get(currentLevelIndex);
	}
	
	public void nextLevel() {
		if(currentLevelIndex < levels.size() - 1) {
			currentLevelIndex++;
		}
	}
    public boolean hasNextLevel() {
        return currentLevelIndex < levels.size() - 1;
    }

    public void reset() {
        currentLevelIndex = 0;
    }
}
