import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

import util.UnitTests;

public class MainWindow {

    private JFrame frame;
    private Model model;
    private Viewer canvas;
    private Controller controller;
    private StartMenu startMenu;
    private LevelSelectionMenu levelSelectionMenu;
    private PauseMenu pauseMenu;
    private LevelWonMenu levelWonMenu;
    private GameOverMenu gameOverMenu;
    private LevelManager levelManager;
    private Level level;

    private GameState gameState = GameState.MENU;

    private Timer gameTimer;
    private long lastTime;

    public MainWindow() {
        initWindow();
        initGame();
        initUI();
        initGameLoop();
    }

    private void initWindow() {
        frame = new JFrame("Game");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setLayout(new BorderLayout());
        frame.setVisible(true);
    }

    private void initGame() {
        controller = new Controller(this::togglePause);
        levelManager = new LevelManager();
        level = levelManager.getCurrentLevel();
        model = new Model(1500f, 775f,controller,level,false);
        canvas = new Viewer(model);

        canvas.setFocusable(true);
        canvas.addKeyListener(controller);

        frame.add(canvas, BorderLayout.CENTER);
        canvas.setVisible(false);
    }

    private void initUI() {

    	startMenu = new StartMenu(
                this::startGame,
                this::exitGame,
                this::showLevelSelection
        );
        startMenu.setBounds(0, 0, frame.getWidth(), frame.getHeight());
        frame.getLayeredPane().add(startMenu, JLayeredPane.MODAL_LAYER);
        
        levelSelectionMenu = new LevelSelectionMenu(
        		levelManager,
        		this::startLevel,
        		this::quitToMenu
        );
        levelSelectionMenu.setVisible(false);
        levelSelectionMenu.setBounds(0,0, frame.getWidth(), frame.getHeight());
        frame.getLayeredPane().add(levelSelectionMenu, JLayeredPane.MODAL_LAYER);

    	pauseMenu = new PauseMenu(
                this::resumeGame,
                this::quitToMenu
        );

        pauseMenu.setVisible(false);
        pauseMenu.setBounds(0, 0, frame.getWidth(), frame.getHeight());
        frame.getLayeredPane().add(pauseMenu, JLayeredPane.MODAL_LAYER);
        
        gameOverMenu = new GameOverMenu(
        	    this::retryGame,
        	    this::quitToMenu
        	);

        gameOverMenu.setVisible(false);
        gameOverMenu.setBounds(0, 0, frame.getWidth(), frame.getHeight());
        frame.getLayeredPane().add(gameOverMenu, JLayeredPane.MODAL_LAYER);
        
        levelWonMenu = new LevelWonMenu(
        		this::retryGame,
        		this::nextLevel,
        		this::quitToMenu
        		);
        levelWonMenu.setVisible(false);
        levelWonMenu.setBounds(0, 0, frame.getWidth(), frame.getHeight());
        frame.getLayeredPane().add(levelWonMenu, JLayeredPane.MODAL_LAYER);

    }

    private void initGameLoop() {
        int targetFPS = 60;
        int delay = 1000 / targetFPS;

        lastTime = System.nanoTime();

        gameTimer = new Timer(delay, e -> gameLoop());
        gameTimer.start();
    }

    private void gameLoop() {
        long now = System.nanoTime();
        double deltaTime = (now - lastTime) / 1_000_000_000.0;
        lastTime = now;

        if (gameState == GameState.PLAYING) {
            model.gamelogic(deltaTime);
            canvas.updateView();
            
            if(model.isGameOver()) {
            	showGameOver();
            }
            
            if(model.isLevelComplete()) {
            	showLevelWon();
            }
        }
    }

	private void startGame() {
		
	    boolean multiplayer = startMenu.isMultiplayerEnabled();
	    model = new Model(1500f, 775f, controller, level, multiplayer); // Add multiplayer parameter
	    canvas.setModel(model);
	    
        gameState = GameState.PLAYING; 
        canvas.setVisible(true);
        startMenu.setVisible(false);
        canvas.requestFocusInWindow();
    }
	
	private void showLevelSelection() {
		startMenu.setVisible(false);
		levelSelectionMenu.setVisible(true);
		gameState = GameState.MENU;
	}
    
    private void exitGame() {
    	System.exit(0);
    }
    
    private void startLevel(int levelIndex) {

        levelManager.reset();

        for (int i = 0; i < levelIndex; i++) {
            levelManager.nextLevel();
        }

        level = levelManager.getCurrentLevel();
        model = new Model(1500f, 775f, controller, level, startMenu.isMultiplayerEnabled());
        canvas.setModel(model);

        startMenu.setVisible(false);
        levelSelectionMenu.setVisible(false);
        canvas.setVisible(true);

        gameState = GameState.PLAYING;
        canvas.requestFocusInWindow();
    }
    
    

    private void togglePause() {
        if (gameState == GameState.PLAYING) {
            gameState = GameState.PAUSED;
            pauseMenu.setVisible(true);
        } else if (gameState == GameState.PAUSED) {
            resumeGame();
        }
    }

    private void resumeGame() {
        gameState = GameState.PLAYING;
        pauseMenu.setVisible(false);
        canvas.requestFocusInWindow();
    }
    
    private void retryGame() {
    	level = levelManager.getCurrentLevel();
    	model = new Model(1500f, 775f, controller, level, startMenu.isMultiplayerEnabled());
    	canvas.setModel(model);
    	
    	gameOverMenu.setVisible(false);
    	levelWonMenu.setVisible(false);
    	canvas.setVisible(true);
    	gameState = GameState.PLAYING;
    	canvas.requestFocusInWindow();
    	}
    
    private void nextLevel() {
    	if(levelManager.hasNextLevel()) {
    		levelManager.nextLevel();
    		level = levelManager.getCurrentLevel();
    		model = new Model(1500f, 775f, controller, level, startMenu.isMultiplayerEnabled());
    		canvas.setModel(model);
    		
    		levelWonMenu.setVisible(false);
    		gameState = GameState.PLAYING;
    		canvas.requestFocusInWindow();
    	} else {
    		quitToMenu();
    	}
    }
    
    private void showLevelWon() {
		gameState = GameState.LEVEL_WON;
		levelWonMenu.updateScore(model);
		levelWonMenu.setVisible(true);
		
	}
    
    private void showGameOver() {
    	gameState = GameState.GAME_OVER;
    	gameOverMenu.setVisible(true);
    }

    private void quitToMenu() {
        gameState = GameState.MENU;
        startMenu.setVisible(true);
        pauseMenu.setVisible(false);
        canvas.setVisible(false);
        levelManager.reset();
        level = levelManager.getCurrentLevel();
        model = new Model(1500f, 775f, controller, level, startMenu.isMultiplayerEnabled());
        canvas.setModel(model);
    }
}