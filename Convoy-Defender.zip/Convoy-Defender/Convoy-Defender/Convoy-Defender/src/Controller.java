import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Controller implements KeyListener {
        
    private static boolean KeyAPressed = false;
    private static boolean KeySPressed = false;
    private static boolean KeyDPressed = false;
    private static boolean KeyWPressed = false;
    private static boolean KeySpacePressed = false;
    private static boolean KeyEnterPressed = false;
    private static boolean KeyEscapePressed = false;
    
    private static boolean KeyDeployP1Pressed = false;
    private static boolean KeyDeployP2Pressed = false;

    private static boolean KeyUpPressed = false;
    private static boolean KeyDownPressed = false;
    private static boolean KeyLeftPressed = false;
    private static boolean KeyRightPressed = false;

    private Runnable onEscape;

    public Controller(Runnable onEscape) {
        this.onEscape = onEscape;
    }

    @Override
    public void keyTyped(KeyEvent e) { 
        // Not used
    }

    @Override
    public void keyPressed(KeyEvent e) { 
        
        int keyCode = e.getKeyCode();

        if (keyCode == KeyEvent.VK_ESCAPE) {
            KeyEscapePressed = true;
            onEscape.run();
            return;
        }

        switch (keyCode) {
            case KeyEvent.VK_A: KeyAPressed = true; break;
            case KeyEvent.VK_S: KeySPressed = true; break;
            case KeyEvent.VK_W: KeyWPressed = true; break;
            case KeyEvent.VK_D: KeyDPressed = true; break;
            case KeyEvent.VK_SPACE: KeySpacePressed = true; break;
            case KeyEvent.VK_ENTER: KeyEnterPressed = true; break;
            case KeyEvent.VK_Q: KeyDeployP1Pressed = true; break;
            case KeyEvent.VK_SHIFT: KeyDeployP2Pressed = true; break;

            // Arrow keys
            case KeyEvent.VK_UP: KeyUpPressed = true; break;
            case KeyEvent.VK_DOWN: KeyDownPressed = true; break;
            case KeyEvent.VK_LEFT: KeyLeftPressed = true; break;
            case KeyEvent.VK_RIGHT: KeyRightPressed = true; break;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) { 
        
        int keyCode = e.getKeyCode();

        switch (keyCode) {
            case KeyEvent.VK_A: KeyAPressed = false; break;
            case KeyEvent.VK_S: KeySPressed = false; break;
            case KeyEvent.VK_W: KeyWPressed = false; break;
            case KeyEvent.VK_D: KeyDPressed = false; break;
            case KeyEvent.VK_SPACE: KeySpacePressed = false; break;
            case KeyEvent.VK_ENTER: KeyEnterPressed = false; break;
            case KeyEvent.VK_ESCAPE: KeyEscapePressed = false; break;
            case KeyEvent.VK_Q: KeyDeployP1Pressed = false; break;
            case KeyEvent.VK_SHIFT: KeyDeployP2Pressed = false; break;

            // Arrow keys
            case KeyEvent.VK_UP: KeyUpPressed = false; break;
            case KeyEvent.VK_DOWN: KeyDownPressed = false; break;
            case KeyEvent.VK_LEFT: KeyLeftPressed = false; break;
            case KeyEvent.VK_RIGHT: KeyRightPressed = false; break;
        }
    }

    // Getters

    public boolean isKeyAPressed() { return KeyAPressed; }
    public boolean isKeySPressed() { return KeySPressed; }
    public boolean isKeyDPressed() { return KeyDPressed; }
    public boolean isKeyWPressed() { return KeyWPressed; }
    public boolean isKeySpacePressed() { return KeySpacePressed; }
    public boolean isKeyEnterPressed() {return KeyEnterPressed;}
    public boolean isKeyEscapePressed() { return KeyEscapePressed; }
    public boolean isKeyDeployP1Pressed() { return KeyDeployP1Pressed; }
    public boolean isKeyDeployP2Pressed() { return KeyDeployP2Pressed; }
    
    public boolean isKeyUpPressed() { return KeyUpPressed; }
    public boolean isKeyDownPressed() { return KeyDownPressed; }
    public boolean isKeyLeftPressed() { return KeyLeftPressed; }
    public boolean isKeyRightPressed() { return KeyRightPressed; }

	public void setKeySpacePressed(boolean b) {	KeySpacePressed = b;}
	
	public void setKeyEnterPressed(boolean b) { KeyEnterPressed = b;}
	public void setKeyDeployP1Pressed(boolean pressed) { KeyDeployP1Pressed = pressed; }
	public void setKeyDeployP2Pressed(boolean pressed) { KeyDeployP2Pressed = pressed; }
	}