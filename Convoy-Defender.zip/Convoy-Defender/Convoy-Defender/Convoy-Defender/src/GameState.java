
public enum GameState {
	MENU,
    PLAYING,
    PAUSED,
    GAME_OVER,
    LEVEL_WON
}
