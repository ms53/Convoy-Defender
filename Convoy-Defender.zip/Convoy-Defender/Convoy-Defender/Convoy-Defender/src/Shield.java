import util.GameObject;

public class Shield {
    private GameObject shieldObject;
    private int remainingHits = 5;

    public Shield(GameObject obj) {
        this.shieldObject = obj;
    }

    public GameObject getShieldObject() { return shieldObject; }

    public int getRemainingHits() { return remainingHits; }
    public void absorbHit() { remainingHits--; }
    public boolean isDestroyed() { return remainingHits <= 0; }
}