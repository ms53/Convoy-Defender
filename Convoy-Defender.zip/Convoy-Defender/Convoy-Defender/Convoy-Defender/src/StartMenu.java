import javax.swing.*;
import java.awt.*;

public class StartMenu extends JPanel {
	
	private JCheckBox multiplayerCheckBox;
	
	public StartMenu(Runnable onStart, Runnable onQuit, Runnable onLevelSelect) {
		
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		setBackground(UIStyle.PANEL_BG);
        setOpaque(true);
        setBorder(BorderFactory.createEmptyBorder(50, 100, 50, 100));

        JLabel title = new JLabel("Convoy Defender");
        title.setFont(UIStyle.TITLE_FONT);
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        add(Box.createVerticalGlue());
        add(title);
        add(Box.createRigidArea(new Dimension(0, 40)));
        add(MenuUIFactory.createMenuButton("Start", onStart));
        add(Box.createRigidArea(new Dimension(0, 15)));
        
        multiplayerCheckBox = new JCheckBox("Enable Multiplayer");
        multiplayerCheckBox.setForeground(Color.WHITE);
        multiplayerCheckBox.setBackground(UIStyle.PANEL_BG);
        multiplayerCheckBox.setAlignmentX(Component.CENTER_ALIGNMENT);
        add(multiplayerCheckBox);
        
        add(MenuUIFactory.createMenuButton("Select Level", onLevelSelect));
        add(Box.createRigidArea(new Dimension(0, 15)));
        add(MenuUIFactory.createMenuButton("Quit", onQuit));
        add(Box.createVerticalGlue());
	}
	
	public boolean isMultiplayerEnabled() {
	    return multiplayerCheckBox.isSelected();
	}
	
}
