import java.awt.Color;
import java.awt.Component;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JButton;

public class UIStyle {
    public static final Color PANEL_BG = new Color(20, 20, 20, 220);
    public static final Color BUTTON_BG = new Color(50, 50, 50);
    public static final Color BUTTON_HOVER = new Color(80, 80, 80);
    public static final Color BUTTON_TEXT = Color.WHITE;

    public static final Font TITLE_FONT = new Font("Arial", Font.BOLD, 36);
    public static final Font BUTTON_FONT = new Font("Arial", Font.BOLD, 18);
    
}
